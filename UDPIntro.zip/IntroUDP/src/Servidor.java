import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

public class Servidor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
                try {
                	
	            //me comunico por aqui
                	DatagramSocket socket = new DatagramSocket(5000);
                	
              	//recibir mensajes
                	
                	byte[] buffer = new byte[1000];
                	DatagramPacket datagrama = new DatagramPacket(buffer, buffer.length);
                	
                	System.out.println(  "esperanding" );       
                	
                //Se congela hasta recibir un mensaje
                	socket.receive(datagrama);
                
                	System.out.println(new String(  datagrama.getData()  )   );
                	
                // responder al cliente
                	String respuesta = "Porque las mujeres no tienen corazon :,v";
                	DatagramPacket datagrama_respuesta = 
                           new DatagramPacket(respuesta.getBytes() , respuesta.getBytes().length, datagrama.getAddress(), datagrama.getPort());       	
                	
                	socket.send(datagrama_respuesta);

                	socket.close();
                	
                } catch (SocketException e) {
                   	   // TODO Auto-generated catch block
                       e.printStackTrace();
                } catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	}

}
