import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

public class Cliente {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        try {
            //me comunico por aqui
        	DatagramSocket socket = new DatagramSocket();
     
        	//Ip del server
        	InetAddress address = InetAddress.getByName("127.0.0.1");
        	
        	//enviar mensaje al servidor
        	String mensaje = "Alguien sabe porque ella no me ama?";
        	DatagramPacket datagrama = new DatagramPacket(mensaje.getBytes(), mensaje.getBytes().length, address, 5000);        	
        	socket.send(datagrama);
        	
         	//recibir mensajes
        	byte[] buffer = new byte[1000];
        	DatagramPacket datagrama_respuesta = new DatagramPacket(buffer,buffer.length);
        	socket.receive(datagrama_respuesta);
        	
        	System.out.println(  "Respuesta: "  +  new String(    datagrama_respuesta.getData()  )  );
        	
        	socket.close();
        	          	       	
          } catch (SocketException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
          } catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
          } catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}	
}
